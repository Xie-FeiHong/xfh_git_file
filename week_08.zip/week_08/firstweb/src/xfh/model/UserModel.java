package xfh.model;

/**
 * Created by xfh on 2017/8/28.
 */
public class UserModel {
    private int id;
    private String name;
    private String pwd;

    public UserModel() {
        super();
        // TODO Auto-generated constructor stub
    }



    public UserModel(String name, String pwd) {
        super();
        this.name = name;
        this.pwd = pwd;
    }


    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }
    public String getUserName() {
        return name;
    }
    public void setUserName(String userName) {
        this.name = userName;
    }
    public String getPassword() {
        return pwd;
    }
    public void setPassword(String password) {
        this.pwd = password;
    }

}
