package xfh.model;

import java.util.Date;

/**
 * Created by xfh on 2017/8/31.
 */
public class BlogModel {
    private int id;
    private String title;
    private Date date;
    private String context;
    private String promulgator;
    private String type;

    public BlogModel() {
        super();
        // TODO Auto-generated constructor stub
    }
    public BlogModel(String title, Date date, String promulgator,String context, String type) {
        super();
        this.title = title;
        this.date = date;
        this.promulgator = promulgator;
        this.context = context;
        this.type = type;
    }
    public BlogModel(String title, Date date, String promulgator) {
        super();
        this.title = title;
        this.date = date;
        this.promulgator = promulgator;
    }

    //=========================================
    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }
    public String getTitle() {
        return title;
    }
    public void setTitle(String title) {
        this.title = title;
    }
    public Date getDate() {
        return date;
    }
    public void setDate(Date date) {
        this.date = date;
    }
    public String getContext() {
        return context;
    }
    public void setContext(String context) {
        this.context = context;
    }
    public String getPromulgator() {
        return promulgator;
    }
    public void setPromulgator(String promulgator) {
        this.promulgator = promulgator;
    }
    public String getType() {
        return type;
    }
    public void setType(String type) {
        this.type = type;
    }
}
