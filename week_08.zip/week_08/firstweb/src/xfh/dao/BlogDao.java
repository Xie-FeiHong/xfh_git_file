package xfh.dao;

import xfh.model.BlogModel;

import java.sql.Clob;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Date;

/**
 * Blog对象的JDBC操作 增 删 改 查
 * Created by xfh on 2017/8/31.
 */
public class BlogDao {
    //最开始主页的显示，查找全部,返回的是一个集合，里面的元素是包含10个BlogModel对象的集合，最后一个有可能不足10个
    public ArrayList select_1(Connection con) throws Exception{
        ArrayList<ArrayList> blogs_index=new ArrayList<ArrayList>();
        ArrayList<BlogModel> subal=null;
        String sql="SELECT title,DATE,promulgator FROM blo_blogs";
        PreparedStatement pstmt= con.prepareStatement(sql);
        ResultSet rs = pstmt.executeQuery();
        int count=0;
        while(rs.next()){
            if(subal==null){
                subal=new ArrayList<BlogModel>();
            }
            String title=rs.getString("title");
            Date date=rs.getDate("date");
            String promulgator=rs.getString("promulgator");
            BlogModel bl = new BlogModel(title,date,promulgator);
            if(subal.size()==10){
                blogs_index.add(subal);
                subal=new ArrayList<BlogModel>();
            }
            subal.add(bl);
            count++;
        }
        blogs_index.add(subal);
        return blogs_index;
    }
    public boolean dleBlog(Connection con,String condition)throws Exception{
        String sql="delete from blo_blogs where title=?";
        PreparedStatement pstmt = con.prepareStatement(sql);
        pstmt.setString(1,condition);
        int result = pstmt.executeUpdate();
        if(result==1) return true;
        return false;
    }
    public BlogModel select_2(Connection con,String condition)throws Exception{
        BlogModel bm=null;
        String sql="select *from blo_blogs where title=?";
        PreparedStatement pstmt = con.prepareStatement(sql);
        pstmt.setString(1,condition);
        ResultSet rs = pstmt.executeQuery();
        if(rs.next()){
            bm=new BlogModel();
            bm.setId(rs.getInt("id"));
            bm.setTitle(rs.getString("title"));
            bm.setDate(rs.getDate("date"));
            Clob c = rs.getClob("content");
            String tent = c.getSubString(1,(int)c.length());
            bm.setContext(tent);
            bm.setPromulgator(rs.getString("promulgator"));
            bm.setType(rs.getString("type"));
        }
        return bm;
    }
    public ArrayList findBlogs(Connection con,String condition)throws  Exception{
        ArrayList<BlogModel> al=null;
        String sql="SELECT title,DATE,promulgator FROM blo_blogs";
        PreparedStatement pstmt = con.prepareStatement(sql);
        ResultSet rs = pstmt.executeQuery();
        while(rs.next()){
            String title = rs.getString("title");
            if(title.contains(condition)){
                if(al==null)al = new ArrayList<BlogModel>();
                al.add(new BlogModel(title,rs.getDate("date"),rs.getString("promulgator")));
            }
        }
        return al;
    }
    public boolean insertBlog(Connection con,BlogModel bm)throws Exception{
        String sql="insert into blo_blogs values(null,?,?,?,?,?)";
        PreparedStatement pstmt = con.prepareStatement(sql);
        pstmt.setString(1,bm.getTitle());
        //把date类型转换成字符串类型 以便可以成功添加数据库
        Date date=bm.getDate();
        String str = date.toLocaleString().split(" ")[0];//切割掉不要的时分秒数据
        pstmt.setString(2,str);
        pstmt.setString(3,bm.getContext());
        pstmt.setString(4,bm.getPromulgator());
        pstmt.setString(5,bm.getType());
        int result = pstmt.executeUpdate();
        if(result==1) return true;
        return false;
    }

    public boolean updateBlog(Connection con,BlogModel bm,int condition)throws Exception{
        String sql="update blo_blogs set title=?,date=?,content=?,promulgator=?,type=? where id=?";
        PreparedStatement pstmt = con.prepareStatement(sql);
        pstmt.setString(1,bm.getTitle());
        //把date类型转换成字符串类型 以便可以成功添加数据库
        Date date=bm.getDate();
        String str = date.toLocaleString().split(" ")[0];//切割掉不要的时分秒数据
        pstmt.setString(2,str);
        pstmt.setString(3,bm.getContext());
        pstmt.setString(4,bm.getPromulgator());
        pstmt.setString(5,bm.getType());
        pstmt.setInt(6,condition);
        int result = pstmt.executeUpdate();
        if(result==1) return true;
        return false;
    }
}
