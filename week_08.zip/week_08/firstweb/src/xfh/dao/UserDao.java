package xfh.dao;

import xfh.model.UserModel;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

/**
 * Created by xfh on 2017/8/28.
 */
public class UserDao {
    public UserModel login(Connection con,UserModel user)throws Exception{
        UserModel resultUser=null;
        String sql="select *from blo_user where userName=? and userPwd=?";
        PreparedStatement pstmt=con.prepareStatement(sql);
        pstmt.setString(1,user.getUserName());
        pstmt.setString(2,user.getPassword());
        ResultSet rs=pstmt.executeQuery();
        if(rs.next()){
            resultUser = new UserModel();
            resultUser.setUserName(rs.getString("userName"));
            resultUser.setPassword(rs.getString("userPwd"));
        }
        return resultUser;
    }
}
