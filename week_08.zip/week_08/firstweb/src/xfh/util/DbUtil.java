package xfh.util;

import java.sql.Connection;
import java.sql.DriverManager;

/**
 * Created by xfh on 2017/8/28.
 */
public class DbUtil {
    private String dbUrl="jdbc:mysql://localhost:3306/db_blogs";
    private String dbUserName="root";
    private String dbPssword="xfhxfh";
    private String jabcName="com.mysql.jdbc.Driver";
    public Connection getCon() throws Exception{
        Class.forName(jabcName);
        Connection con= DriverManager.getConnection(dbUrl,dbUserName,dbPssword);
        return con;
    }
    public void closeCon(Connection con)throws Exception{
        if(con!=null){
            con.close();;
        }
    }
}
