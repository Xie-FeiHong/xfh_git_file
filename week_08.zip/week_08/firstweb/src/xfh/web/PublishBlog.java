package xfh.web;

import xfh.dao.BlogDao;
import xfh.model.BlogModel;
import xfh.util.DbUtil;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.Connection;
import java.text.SimpleDateFormat;
import java.util.Date;


/**
 * Created by xfh on 2017/9/1.
 */
public class PublishBlog extends HttpServlet{
    /**
     *
     */
    private static final long serialVersionUID = 1L;

    DbUtil dbUtil= new DbUtil();
    BlogDao blogDao = new BlogDao();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        this.doPost(request, response); //交给doPost处理
    }
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding("utf-8");
        String title = request.getParameter("pul_title");
        String type = request.getParameter("pul_type");
        //形成时间
        String year = request.getParameter("pul_date_year");
        String month = request.getParameter("pul_date_month");
        String day = request.getParameter("pul_date_day");
        Date date=null;
        String str=year+"-"+month+"-"+day;
        try{
             date= new SimpleDateFormat("yyyy-MM-dd").parse(str);
        }
        catch (Exception e){
            e.printStackTrace();
        }
        String content = request.getParameter("pul_content");
        HttpSession session = request.getSession();
        String promulgator = session.getAttribute("currentUserName").toString();
        //检查输出
       /* System.out.println("标题："+title);
        System.out.println("类型："+type);
        System.out.println("时间："+date.toString());
        System.out.println("发布者："+promulgator);
        System.out.println("内容："+content);*/

        //创建BlogModel
        BlogModel bm = new BlogModel(title,date,promulgator,content,type);

        Connection con = null;
        try{
            con = dbUtil.getCon();
            //判断是添加还是更新
            String info_flag = request.getParameter("update_flag");
            System.out.println("flag的值"+info_flag);
            if("更新".equals(info_flag)){
                //调用更新的方法
                String  str_condition = request.getParameter("update_condition");
                int up_condition=Integer.parseInt(str_condition);
                boolean up_f = blogDao.updateBlog(con,bm,up_condition);
                if(up_f){
                    session.setAttribute("hint","更新成功");
                }
                else{
                    session.setAttribute("hint","更新失败");
                }
                request.getRequestDispatcher("index.jsp").forward(request,response);
            }
            else{
                //加入数据库
                boolean flag =blogDao.insertBlog(con,bm);
                //设置session值，在主页弹出信息框，告诉浏览器添加成功
                if(flag){
                    session.setAttribute("hint","添加成功");
                }
                else{
                    session.setAttribute("hint","添加失败");
                }
                request.getRequestDispatcher("index.jsp").forward(request,response);
            }
        }
        catch (Exception e){
            e.printStackTrace();
        }
        finally {
            if(con!=null){
                try{
                    con.close();
                }catch (Exception e1){e1.printStackTrace();}
            }
        }
    }
}
