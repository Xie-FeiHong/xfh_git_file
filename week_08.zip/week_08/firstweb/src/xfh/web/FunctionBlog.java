package xfh.web;

import xfh.dao.BlogDao;
import xfh.model.BlogModel;
import xfh.util.DbUtil;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.Connection;
import java.util.ArrayList;

/**
 * Created by xfh on 2017/9/1.
 */
public class FunctionBlog extends HttpServlet{
    /**
     *
     */
    private static final long serialVersionUID = 1L;

    DbUtil dbUtil= new DbUtil();
    BlogDao blogDao = new BlogDao();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        this.doPost(request, response); //交给doPost处理
    }
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding("utf-8");
        String fun_info=request.getParameter("fun");
        String title = request.getParameter("index_info");
        //解决乱码的问题
        fun_info = new String(fun_info.getBytes("ISO-8859-1"),"UTF-8");
        fun_info = java.net.URLDecoder.decode(fun_info,"UTF-8");
        title = new String(title.getBytes("ISO-8859-1"),"UTF-8");
        title = java.net.URLDecoder.decode(title,"UTF-8");

        HttpSession session = request.getSession();
        //判断具体干什么
        if(fun_info.equals("删除")){
            //删除对应标题的博客
            Connection con=null;
            try{
                 con = dbUtil.getCon();
                blogDao.dleBlog(con,title);
                //返回主页面并刷新
                ArrayList<ArrayList> al = blogDao.select_1(con);
                String str = session.getAttribute("subscript").toString();
                int index=Integer.parseInt(str);
                session.setAttribute("index_al",al.get(index-1));
                request.getRequestDispatcher("index.jsp").forward(request,response);
            }
            catch (Exception e){
                e.printStackTrace();
            }finally {
                if(con!=null){
                    try{
                        con.close();
                    }catch (Exception e1){e1.printStackTrace();}
                }
            }


        }
        else {
            Connection con=null;
            try{
                con = dbUtil.getCon();
                BlogModel bm = blogDao.select_2(con,title);
                //数据传给显示页面
                session.setAttribute("show_author",bm.getPromulgator());
                session.setAttribute("show_title",bm.getTitle());
                session.setAttribute("show_type",bm.getType());
                session.setAttribute("show_content",bm.getContext());
                //分割时间
                String re = "-";
                String[] dt = bm.getDate().toString().split(re);
                session.setAttribute("show_date_year",dt[0]);
                session.setAttribute("show_date_month",dt[1]);
                session.setAttribute("show_date_day",dt[2]);
                session.setAttribute("show_condition",bm.getId());
                if(fun_info.equals("查看")){
                    //查看对应标题的博客
                    request.getRequestDispatcher("showBlog.jsp").forward(request,response);
                }
                else{
                    //编辑对应标题的博客
                    request.getRequestDispatcher("editBlog.jsp").forward(request,response);
                }
            }
            catch (Exception e){
                e.printStackTrace();
            }finally {
                if(con!=null){
                    try{
                        con.close();
                    }catch (Exception e1){e1.printStackTrace();}
                }
            }
        }
    }
}
