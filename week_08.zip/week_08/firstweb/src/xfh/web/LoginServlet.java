package xfh.web;

import xfh.dao.BlogDao;
import xfh.dao.UserDao;
import xfh.model.UserModel;
import xfh.util.DbUtil;

import java.io.IOException;
import java.sql.Connection;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Created by xfh on 2017/8/28.
 */
public class LoginServlet extends HttpServlet {
    /**
     *
     */
    private static final long serialVersionUID = 1L;
    DbUtil dbUtil= new DbUtil();
    UserDao userDao = new UserDao();
    BlogDao blogDao = new BlogDao();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        this.doPost(request, response);
    }
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding("utf-8");
        String userName=request.getParameter("name");
        String password=request.getParameter("pwd");
        Connection con = null;
        try{
            UserModel user = new UserModel(userName,password);
            con=dbUtil.getCon();
            UserModel currentUser = userDao.login(con,user);
            if(currentUser==null){
                request.setAttribute("error","用户名或者密码错误");
                request.setAttribute("userName", userName);
                request.setAttribute("password",password );
                request.getRequestDispatcher("login.jsp").forward(request,response);
            }
            else{
                //System.out.println("账号存在");
                //还要传对象 获取对象 request设置对象
                ArrayList<ArrayList> al=blogDao.select_1(con);
                HttpSession session = request.getSession();
                session.setAttribute("subscript",1);
                session.setAttribute("index_al",al.get(0));
                session.setAttribute("currentUserName",userName);
                request.getRequestDispatcher("index.jsp").forward(request,response);
                //response.sendRedirect("index.jsp"); //重定向
            }
        }catch (Exception e){
            e.printStackTrace();
            throw new RuntimeException("校验登录失败");
        }finally {
            if(con!=null){
                try{
                    con.close();
                }
                catch (Exception e1){e1.printStackTrace();}
            }
        }
    }
}
