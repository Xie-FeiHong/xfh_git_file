package xfh.web;

import xfh.dao.BlogDao;
import xfh.util.DbUtil;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.Connection;
import java.util.ArrayList;

/**
 * Created by xfh on 2017/8/31.
 */
public class IndexServlet extends HttpServlet {
    /**
     *
     */
    private static final long serialVersionUID = 1L;
    DbUtil dbUtil= new DbUtil();
    BlogDao blogDao = new BlogDao();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        this.doPost(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding("utf-8");
        ArrayList<ArrayList> al=null;
        Connection con=null;
        try{
            con=dbUtil.getCon();
             al=blogDao.select_1(con);
        }
        catch (Exception e){
            e.printStackTrace();
            throw new RuntimeException("获取al失败");
        }finally {
            if(con!=null){
                try{
                    con.close();
                }
                catch (Exception e1){e1.printStackTrace();}
            }
        }

        String info=request.getParameter("info");
//        System.out.println("后台接收的信息为"+info);
        int sum=al.size();
        HttpSession session = request.getSession();
        String str = session.getAttribute("subscript").toString();
//        System.out.println(str);
        int index=Integer.parseInt(str);
//        System.out.println("当前的下标："+index);
        //判断
        switch (info){
            case "上一页":
                if(index>1){
                    session.setAttribute("subscript",index-1);
                    session.setAttribute("index_al",al.get(index-2));
                    break;
                }
            case "1":
                session.setAttribute("subscript",1);
                session.setAttribute("index_al",al.get(0));
                break;
            case "2":
                if(sum>=2){
                    session.setAttribute("subscript",2);
                    session.setAttribute("index_al",al.get(1));
                    break;
                }
            case "3":
                if(sum>=3){
                    session.setAttribute("subscript",3);
                    session.setAttribute("index_al",al.get(2));
                    break;
                }
            case "4":
                if(sum>=4){
                    session.setAttribute("subscript",4);
                    session.setAttribute("index_al",al.get(3));
                    break;
                }
            case "245":
                if(sum>=245){
                    session.setAttribute("subscript",245);
                    session.setAttribute("index_al",al.get(244));
                    break;
                }
            case "下一页":
                if(index<sum){
                    session.setAttribute("subscript",index+1);
                    session.setAttribute("index_al",al.get(index));
                    break;
                }
            case "最后一页":
                session.setAttribute("subscript",sum);
                session.setAttribute("index_al",al.get(sum-1));
                break;
        }
        request.getRequestDispatcher("index.jsp").forward(request,response);
    }
}
