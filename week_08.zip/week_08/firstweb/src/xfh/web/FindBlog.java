package xfh.web;

import xfh.dao.BlogDao;
import xfh.util.DbUtil;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.Connection;
import java.util.ArrayList;

/**
 * Created by xfh on 2017/9/1.
 */
public class FindBlog extends HttpServlet{
    /**
     *
     */
    private static final long serialVersionUID = 1L;

    DbUtil dbUtil= new DbUtil();
    BlogDao blogDao = new BlogDao();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        this.doPost(request, response); //交给doPost处理
    }
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding("utf-8");
        String title = request.getParameter("sel");
        Connection con = null;
        try{
            //调用方法查找，然后返回集合
            con=dbUtil.getCon();
            ArrayList al=blogDao.findBlogs(con,title);
            HttpSession session = request.getSession();
            session.setAttribute("index_al",al);
            request.getRequestDispatcher("index.jsp").forward(request,response);
        }
        catch (Exception e){
            e.printStackTrace();
        }
        finally {
            if(con!=null){
                try{
                    con.close();
                }catch (Exception e1){e1.printStackTrace();}
            }
        }
    }
}
