package JDBCDome;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.sql.*;

/**
 * Created by xfh on 2017/8/12.
 */
public class Dome {
    private static DbUtil dbUtil = new DbUtil();

    public static void main(String[] args) throws Exception{
        File context = new File("helloWorld.txt");
        File pic = new File("pic.jpg");

        //添加图书
        Book book = new Book("学习Java",120,"无名",1,context,pic);
        int i_result = addBook(book);
        if(i_result==1){
            System.out.println("添加成功！");
        }else{
            System.out.println("添加失败！");
        }
        //更新图书
        Book book2 = new Book(3,"学习Java",120,"无名",1,context,pic);
        int u_result = updataBook(book2);
        if(u_result==1){
            System.out.println("更新成功！");
        }else{
            System.out.println("更新失败！");
        }

        //查看图书
        System.out.println("=======================================================\n查询结果如下");
        selectBook(7);
        System.out.println("=======================================================");
        //删除图书
        int d_result = delectBook(11);
        if(d_result==1){
            System.out.println("删除成功！");
        }else{
            System.out.println("没有对应编号的图书，删除失败！");
        }
    }

    //添加图书
    private static int addBook(Book book)throws Exception{
        Connection  con = dbUtil.getCon();
        String sql = "insert into t_book values(null,?,?,?,?,?,?)";
        PreparedStatement pstmt = con.prepareStatement(sql);
        pstmt.setString(1,book.getBookName());
        pstmt.setFloat(2,book.getPrice());
        pstmt.setString(3,book.getAuthor());
        pstmt.setInt(4,book.getBookTypeId());
        File context = book.getContext();
        InputStream ins = new FileInputStream(context);
        pstmt.setAsciiStream(5,ins,context.length());
        File pic = book.getPic();
        InputStream ins2 = new FileInputStream(pic);
        pstmt.setBinaryStream(6,ins2,pic.length());
        int result = pstmt.executeUpdate();
        dbUtil.close(pstmt,con);
        return result;
    }

    //查看图书
    private static void selectBook(int id) throws Exception{
        Connection con = dbUtil.getCon();
        String sql = "select *from t_book Where id=?";
        PreparedStatement pstmt = con.prepareStatement(sql);
        pstmt.setInt(1, id);
        ResultSet rs = pstmt.executeQuery(); //返回结果集
        if(rs.next()){
            //int id = rs.getInt("id");	//获取第一个列的值 编号id
            String bookName=rs.getString("bookName"); //获取第二个列的值 bookName
            float price=rs.getFloat("price"); //获取第三列的值 price
            String author = rs.getString("author"); //获取第四列的值 作者author
            int bookTypeId=rs.getInt("bookTypeId"); //获取第五列的值 图书类别bookTypeId

            Clob c = rs.getClob("context");
            String context = c.getSubString(1, (int)c.length());

            Blob b = rs.getBlob("pic");
            int count=1;
            File p = new File("pic.jpg");
            while(p.exists())
                 p  = new File("pic"+(count++)+".jpg");
            FileOutputStream fos = new FileOutputStream(p);
            fos.write(b.getBytes(1, (int)b.length()));
            System.out.println("图书编号："+id+"图书名称:"+bookName+"图书价格："+price+"图书作者："+author+"图书类别："+bookTypeId);
            System.out.println("图书内容："+context);
            //System.out.println("===============================================================================================");
        }
        dbUtil.close(pstmt, con);
    }

    //删除图书
    public static int  delectBook(int id)throws Exception{
        Connection con = dbUtil.getCon();
        String sql = "delete from t_book where id=?";
        PreparedStatement pstmt = con.prepareStatement(sql);
        pstmt.setInt(1,id);
        int result = pstmt.executeUpdate();
        return result;
    }


    //更新图书
    private static int updataBook(Book book)throws Exception{
        Connection  con = dbUtil.getCon();
        String sql = "update  t_book set bookName=?,price=?,author=?,bookTypeId=?,context=?,pic=? where id=?";
        PreparedStatement pstmt = con.prepareStatement(sql);
        pstmt.setString(1,book.getBookName());
        pstmt.setFloat(2,book.getPrice());
        pstmt.setString(3,book.getAuthor());
        pstmt.setInt(4,book.getBookTypeId());
        File context = book.getContext();
        InputStream ins = new FileInputStream(context);
        pstmt.setAsciiStream(5,ins,context.length());
        File pic = book.getPic();
        InputStream ins2 = new FileInputStream(pic);
        pstmt.setBinaryStream(6,ins2,pic.length());
        pstmt.setInt(7,book.getId());
        int result = pstmt.executeUpdate();
        dbUtil.close(pstmt,con);
        return result;
    }




}
