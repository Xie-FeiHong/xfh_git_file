
import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;

/**
 * 服务端线程
 * Created by xfh on 2017/8/5.
 */
public class ServerThread implements Runnable {
    public void run(){
        ServerSocket ss = null;
        Socket s = null;
        try{
             ss = new ServerSocket(10009);
             s = ss.accept();

            String ip = s.getInetAddress().getHostName();
            System.out.println(ip+"....connected");
            //读取Socket中的数据
            BufferedReader bufIn =
                    new BufferedReader(new InputStreamReader(s.getInputStream()));

            //获取输出流，反馈信息给客户端
            BufferedWriter bufOut =
                    new BufferedWriter(new OutputStreamWriter(s.getOutputStream()));

            String line = null;
            while((line = bufIn.readLine())!=null){
                System.out.println("\t\t\t\t\t接收信息为：\t"+line);
                bufOut.write("信息已收到！");
                bufOut.newLine();
                bufOut.flush();
            }

        }
        catch(Exception e){
            e.printStackTrace();
        }finally {
            try{
                if(s!=null)
                    s.close();
            }
            catch (Exception e1){
                e1.printStackTrace();
            }finally {
                try{
                    if(ss!=null)
                        ss.close();
                }
                catch (Exception e2){
                    e2.printStackTrace();
                }
            }
        }

    }
}
