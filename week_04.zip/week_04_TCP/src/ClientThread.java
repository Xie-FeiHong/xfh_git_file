import java.io.*;
import java.net.Socket;

/**
 * 定义一个线程类，实现客户端
 * Created by xfh on 2017/8/5.
 */
public class ClientThread implements Runnable {
    public void run() {
        System.out.println("在控制台输入over可以接收程序");
        Socket s = null;
        BufferedReader bufr =null;
        try{
             s = new Socket("192.168.8.3",10009);//创建Socket对象
            //定义读取键盘数据的流对象
             bufr = new BufferedReader(new InputStreamReader(System.in));

            //定义目的，将数据写入到Socket输出流，发给服务端
            BufferedWriter bufout =
                    new BufferedWriter(new OutputStreamWriter(s.getOutputStream()));

            //定义一个Socket读取流，读取服务端返回的信息
            BufferedReader bufIn =
                    new BufferedReader(new InputStreamReader(s.getInputStream()));

            String line = null;
            while ((line = bufr.readLine())!=null){
                if("over".equals(line))
                    break;
                bufout.write(line);
                bufout.newLine();
                bufout.flush();
                String str = bufIn.readLine();
                System.out.println("server:"+str);
            }
        }
        catch(Exception e){
            e.printStackTrace();
        }
        finally {
            try{
                if(bufr!=null)
                    bufr.close();
            }
            catch (Exception e1){
                e1.printStackTrace();
            }finally {
                try{
                    if(s!=null)
                        s.close();
                }
                catch (Exception e2){
                    e2.printStackTrace();
                }
            }
        }
    }
}
