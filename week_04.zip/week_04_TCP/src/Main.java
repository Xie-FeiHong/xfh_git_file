/**
 *
 * Created by xfh on 2017/8/5.
 */
public class Main {
    public static void main(String[] args){
        Thread t1 = new Thread(new ClientThread());
        Thread t2 = new Thread(new ServerThread());
        t1.start();
        t2.start();

    }
}
