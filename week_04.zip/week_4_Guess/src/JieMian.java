package week_04.week_04_02;

import java.util.Scanner;
import static java.lang.System.exit;

/**
 * Created by xfh on 2017/8/3.
 */
public class JieMian {
    PaiHangBang P = new PaiHangBang();
    public void zhuJieMian(){
        System.out.println("-------------------------------------------------");
        System.out.println("游戏说明：\n电脑会随机产生一个非负整数r，用户输入一个数h\n电脑会给出互大或小的提示，直到猜对为止");
        xuanXiangJieMian();
    }
    private void xuanXiangJieMian() {
        System.out.println("\n");
        System.out.println("输入选项后的字母就可以选择该选项");
        System.out.println("1、游戏开始(k)\t2、游戏退出(t)\t3、再来一次(z)\t4、查看排行榜纪录(c)");
        System.out.println("你的选择：");
        Scanner o = new Scanner(System.in);
        String sc = o.next();
        char s = sc.charAt(0);
        switch (s) {
            case 'k':
                run();
                break;
            case 't':
                P.close();
                exit(0);
                break;
            case 'z':
                run();
                break;
            case 'c':chaKan();
                break;
            default:
                System.out.println("输入的字符不合法！");
                xuanXiangJieMian();
        }
    }
    private void run(){
        System.out.println("\n\n-------------------------------------------------");
        RandomShu R = new RandomShu();
        int r = R.getRandomShu();
        System.out.println("已生成一个0~20的随机数r（包括0和20）");
        InputShu I = new InputShu();
        int h = I.getInputShu();
        do {
            if(r==h){
                System.out.println("恭喜您猜对了！共猜了"+I.getNum()+"次");
                P.add(I.getNum());
                xuanXiangJieMian();
            }else if(h>=0&&h<r){
                prin(1);
                h = I.getInputShu();
            }else if(h>r&&h<=20){
                prin(2);
                h = I.getInputShu();
            }else {
                System.out.println("您输入的数字不再范围内！");
                h = I.getInputShu();
            }
        }while(true);
    }
    private void prin(int m){
        if(m==1) System.out.println("您输入的数字小了");
        else System.out.println("您输入的数字大了");
    }
    private void chaKan(){
        P.show();
        xuanXiangJieMian();
    }
}
