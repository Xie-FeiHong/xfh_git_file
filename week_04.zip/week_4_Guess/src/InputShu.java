package week_04.week_04_02;

import java.util.Scanner;

/**
 * Created by xfh on 2017/8/3.
 */
public class InputShu {
    private int num=0;
    private int H;
    public int  getInputShu(){
        System.out.println("\n请输入你猜测的数据");
        Input();
        num++;
        return this.H;
    }
    private  void Input(){
        Scanner x = new Scanner(System.in);
        H = x.nextInt();
    }
    public int getNum(){
        return num;
    }
}
