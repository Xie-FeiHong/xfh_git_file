package week_04.week_04_02;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Arrays;


/**
 * Created by xfh on 2017/8/3.
 */
public class PaiHangBang {
    private FileWriter fw = null;
    private FileReader fr = null;
    private  boolean falg = false;

    public void show(){
        try{
            fr = new FileReader("Rank.txt");
        }
        catch (IOException e){
            throw new RuntimeException("创建读写失败");
        }
        if(falg){
            char[] buf = new char[100];
            int len = 0;
            try{
                while((len = fr.read(buf))!=-1){
                    Arrays.sort(buf,0,len);
                    String str = new String(buf,0,len);
                    for(int x=0;x<len;x++){
                        char c = str.charAt(x);
                        System.out.println("第"+(x+1)+"名：共猜"+c+"次");
                    }
                }
            }catch (IOException e){
                throw new RuntimeException("读取失败");
            }
        }
        else{
            System.out.println("还没有开始游戏，没有任何记录");
        }

        try{
            if(fr!=null)
                fr.close();
        }catch (IOException e){
            throw new RuntimeException("关闭读失败！");
        }
    }
    public void add(int x){
        try{
            fw.write(""+x);
            fw.flush();
            if(!falg)
                falg = true;
        }
        catch (IOException e){
            throw new RuntimeException("存入数据失败！");
        }
    }
    public PaiHangBang(){
        try{
            fw = new FileWriter("Rank.txt");
        }
        catch (IOException e){
            throw new RuntimeException("创建读写失败");
        }
    }
    public void close(){
        try{
            if(fw!=null)
                fw.close();
        }
        catch (IOException e){
            throw new RuntimeException("关闭写失败！");
        }
    }
}
