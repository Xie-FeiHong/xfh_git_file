package week_04.week_04_02;


/**
 * 第四周作业——完善猜数字小游戏
 * Created by xfh on 2017/8/3.
 */
public class Main {
    public static  void main(String[] args){
        week_04.week_04_02.JieMian f = new week_04.week_04_02.JieMian();
        f.zhuJieMian();
    }
}
