package week_04.week_04_02;

import java.util.Random;

/**
 * Created by xfh on 2017/8/3.
 */
public class RandomShu {
    private int run(){
        int S = new Random().nextInt(20);
        return S;
    }
    public int getRandomShu(){
        int S = run();
        return S;
    }
}
